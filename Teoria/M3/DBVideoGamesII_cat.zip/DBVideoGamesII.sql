-- We assume the videogames SCHEMA exists and that the entire first part (BDVideoGamesI.sql) has been executed, with the exception of the DROP SCHEMA and the final SEARCH_PATH SET

-- 1 Stored procedures

-- 1 a
CREATE TYPE avlb_copies_video_games AS (
	game_code INTEGER,
	game_name VARCHAR(30),
	rental_fee DECIMAL(5,2),
	min_age INTEGER,
	total_amount INTEGER,
	total_rent INTEGER);
	
BEGIN WORK;

CREATE OR REPLACE FUNCTION avlb_copies_video_games ()
RETURNS SETOF avlb_copies_video_games AS '

DECLARE
  video_cursor avlb_copies_video_games;

BEGIN
  FOR video_cursor IN 
    SELECT 
      game_code, 
      game_name, 
      rental_fee, 
      min_age, 
      total_amount, 
      total_amount-(SELECT COUNT(*) 
                   FROM game_rental 
                   WHERE game_code = v.game_code AND ret_date IS NULL) AS total_rent 
    FROM video_games v  
    GROUP BY game_code, game_name, rental_fee, min_age, total_amount 
    ORDER BY game_code
  LOOP	
RETURN NEXT video_cursor;
END LOOP;

RETURN;
END;
' LANGUAGE plpgsql;

COMMIT WORK;

-- Run stored procedure
BEGIN WORK;
SELECT * FROM avlb_copies_video_games();
COMMIT WORK;

-- 1 b
BEGIN WORK;

CREATE OR REPLACE FUNCTION increase_salaries(percentage DECIMAL(5,2), num_act_rent INTEGER)
RETURNS void AS '

DECLARE
   -- definition of variables
   num_empl employees.empl_code%TYPE;
   empl_salary employees.salary%TYPE;
   total INTEGER := 0;

BEGIN
   -- program body
   FOR num_empl, empl_salary IN SELECT empl_code, salary 
 	           FROM employees 
		    WHERE empl_code IN (SELECT ll.empl_code FROM game_rental ll
		                         WHERE ll.ret_date IS NULL
		                         GROUP BY ll.empl_code
                                         HAVING COUNT(*)>=num_act_rent) LOOP
   total := total + 1;

   -- provided that maximum salary is exceeded
   IF (empl_salary*(1+percentage/100))>800 THEN 
       RAISE EXCEPTION ''%: maximum salary exceeded '', -746;
   ELSE 
       UPDATE employees SET salary = salary*(1+ percentage/100) WHERE empl_code = num_empl; 
   END IF;
END LOOP;

-- provided that there are no updates
IF total = 0 THEN 
  RAISE EXCEPTION ''%: No employee meets the conditions for an increase in salary'', -746;
END IF;

END;
' LANGUAGE plpgsql;

COMMIT WORK;

BEGIN WORK;

-- Execution with exception "-746: No employee meets the conditions for an increase in salary"

SELECT increase_salaries (10,10);

-- we could have also run COMMIT 

ROLLBACK WORK;

BEGIN WORK;

-- Employers who meet the increase salary conditions
-- are employees 1, 2, 3 and 4

SELECT salary, empl_code FROM employees
WHERE empl_code IN (SELECT ll.empl_code
                      FROM game_rental ll
		      WHERE ll.ret_date IS NULL
		      GROUP BY ll.empl_code
	              HAVING COUNT(*) >= 1);

-- Execution with exception "-746: Maximum salary exceeded"
-- The employer who will cause the exception to raise will be the employer with empl_code equal to 3

SELECT increase_salaries(100,1);

-- Check that the salaries of employees with codes 1 and 2 were modified
-- The salary of employee with code 3 was not modified (error, maximum salary exceeded)
-- The salary of employee with code 4 was not considered

SELECT salary, empl_code FROM employees
WHERE empl_code IN (SELECT ll.empl_code
                      FROM game_rental ll
  		      WHERE ll.ret_date IS NULL
		      GROUP BY ll.empl_code
	              HAVING COUNT(*) >= 1);

-- Mandatorily cancel results (in response to the query) 

ROLLBACK WORK;

BEGIN WORK;

-- Correct execution
-- Only employee with code equal to 1 meets the conditions

SELECT * FROM employees WHERE empl_code = 1;

SELECT increase_salaries(10,4);

-- The salary was increased by 10%

SELECT * FROM employees WHERE empl_code = 1;

COMMIT WORK;

-- Optimized alternative version

BEGIN WORK;

CREATE OR REPLACE FUNCTION increase_salaries(percentage DECIMAL(5,2), num_act_rent INTEGER)
RETURNS void AS '

BEGIN
   UPDATE employees SET salary = (salary+(salary*percentage*0.01)) WHERE empl_code IN (SELECT ll.empl_code 
   FROM game_rental ll, employees e
   WHERE ll.ret_date IS NULL AND ll.empl_code = e.empl_code 
   GROUP BY ll.empl_code
   HAVING COUNT(*)>=num_act_rent) ;

   -- provided that there are no updates
   IF NOT FOUND THEN 
     RAISE EXCEPTION ''%: No employee meets the conditions for an increase in salary'', -746;
   END IF;

   EXCEPTION
     WHEN CHECK_VIOLATION THEN
       RAISE EXCEPTION ''%: Maximum salary exceeded'', -746;

END;
' LANGUAGE plpgsql;

COMMIT WORK;

-- 2 triggers
-- 2 a
BEGIN WORK;

CREATE OR REPLACE FUNCTION insert_rent() 
RETURNS TRIGGER AS '

DECLARE
total_rent INTEGER;

BEGIN

   -- appropriate age?
   IF ((SELECT COUNT(*)
         FROM customers c, video_games v
         WHERE  v.game_code = NEW.game_code AND 
                c.customer_code= NEW.customer_code AND 
                c.age < v.min_age)<>0) 
         THEN RAISE EXCEPTION ''%: The rental cannot be arranged: inappropriate age'', -746;
   END IF;

   -- enough copies?
   SELECT COUNT(*) INTO total_rent
   FROM game_rental ll
   WHERE ll.game_code = NEW.game_code AND ll.ret_date IS NULL;

   IF (total_rent >= (SELECT v.total_amount FROM video_games v WHERE v.game_code = NEW.game_code))
       THEN RAISE EXCEPTION ''%: The rental cannot be arranged: no copies left in stock'', -746;
   END IF;	         

   -- initial rental date is correct?
   IF (NEW.rental_date> CURRENT_DATE) THEN 
      RAISE EXCEPTION ''%: The rental cannot be arranged: rental date later than current date'', -746; 
   END IF;

   -- final rental date is correct?
   IF (NEW.ret_date IS NOT NULL) THEN 
      RAISE EXCEPTION ''%: The rental cannot be arranged: return date is not NULL'', -746;
   END IF;

RETURN NEW;

END;

' LANGUAGE plpgsql;


CREATE TRIGGER insert_rent
AFTER INSERT ON game_rental
FOR EACH ROW EXECUTE PROCEDURE insert_rent();

COMMIT WORK;

BEGIN WORK;

-- Inappropriate customer game age 

INSERT INTO game_rental VALUES(4,3,CURRENT_DATE,NULL,1);

ROLLBACK WORK;


BEGIN WORK;

-- Correct insertion

INSERT INTO game_rental VALUES(7,7,'03-06-2006',NULL,1);
	
COMMIT WORK;

BEGIN WORK;

-- No copies left in stock

INSERT INTO game_rental VALUES(7,7,CURRENT_DATE,NULL,1);

ROLLBACK WORK;

BEGIN WORK;

-- Rental date later than current date

INSERT INTO game_rental VALUES(6,7,'12-31-2030',NULL,1);

ROLLBACK WORK;

BEGIN WORK;

-- Return date not null

INSERT INTO game_rental VALUES(6,7,CURRENT_DATE,'03-31-2030',1);

ROLLBACK WORK;

-- 2 b
BEGIN WORK;

--DROP VIEW rental_empl;
--DROP VIEW february_rentals;
DELETE FROM game_rental;
DELETE FROM employees;
DROP TABLE game_rental;
DROP TABLE employees;

CREATE TABLE employees(
	empl_code INTEGER,
	empl_name VARCHAR(50) NOT NULL,
	salary DECIMAL(5,2) NOT NULL,
	age INTEGER NOT NULL,
	num_rent INTEGER DEFAULT 0 NOT NULL,
	CONSTRAINT pk_employees PRIMARY KEY(empl_code),
	CONSTRAINT u_employees UNIQUE(empl_name),
	CONSTRAINT ck_salary CHECK(salary BETWEEN 300 AND 800),
	CONSTRAINT ck_empl_age CHECK(age BETWEEN 18 AND 65)
);

CREATE TABLE game_rental(
	game_code INTEGER, 
	customer_code INTEGER, 
	rental_date DATE DEFAULT CURRENT_DATE, 
	ret_date DATE DEFAULT NULL, 
	empl_code INTEGER NOT NULL,
	CONSTRAINT pk_game_rental PRIMARY KEY (game_code, customer_code, rental_date),
	CONSTRAINT fk_video_games FOREIGN KEY(game_code) REFERENCES video_games(game_code),
	CONSTRAINT fk_customers FOREIGN KEY(customer_code) REFERENCES customers(customer_code),
	CONSTRAINT fk_employees FOREIGN KEY(empl_code) REFERENCES employees(empl_code),
	CONSTRAINT ck_dates CHECK(ret_date IS NULL OR rental_date <= ret_date)
);

INSERT INTO employees VALUES(1, 'Ramon Pi', 350, 21, 0);
INSERT INTO employees VALUES(2, 'Sara Ruso', 400, 40, 0);
INSERT INTO employees VALUES(3, 'Juan Paz', 600, 25, 0);
INSERT INTO employees VALUES(4, 'Angel Ros', 350.25, 18, 0);
INSERT INTO employees VALUES(5, 'Marc Coimbra', 500, 40, 0);

SELECT * FROM employees;

COMMIT WORK;

-- Modifications to the previous exercise (procedure and trigger)
-- Delete previous elements and create again with the applied modifications 

BEGIN WORK;

-- Since the game_rental table was deleted and created again, the DBMS has automatically deleted the trigger

CREATE OR REPLACE FUNCTION insert_rental() 
RETURNS TRIGGER AS '

DECLARE
total_rent INTEGER;

BEGIN

   -- appropriate age?
   IF ((SELECT COUNT(*)
         FROM customers c, video_games v
         WHERE  v.game_code = NEW.game_code AND 
                c.customer_code= NEW.customer_code AND 
                c.age < v.min_age) <> 0) 
         THEN RAISE EXCEPTION ''%: The rental cannot be arranged: inappropriate customer age'', -746;
   END IF;

   -- enough copies?
   SELECT COUNT(*) INTO total_rent
   FROM game_rental ll
   WHERE ll.game_code=NEW.game_code AND ll.ret_date IS NULL;

   IF (total_rent > (SELECT v.total_amount FROM video_games v WHERE v.game_code = NEW.game_code))
       THEN RAISE EXCEPTION ''%: The rental cannot be arranged: no copies left in stock'', -746;
   END IF;	         

   -- initial rental date is correct?
   IF (NEW.rental_date> CURRENT_DATE) THEN 
      RAISE EXCEPTION ''%: The rental cannot be arranged: incorrect date'', -746; 
   END IF;

   -- final rental date is correct?
   IF (NEW.ret_date IS NOT NULL) THEN 
      RAISE EXCEPTION ''%: The rental cannot be arranged: return date is not NULL'', -746;
   END IF;

   -- note down that the employee has arranged a new rental 
   UPDATE employees SET num_rent=num_rent+1 WHERE empl_code = NEW.empl_code;

RETURN NEW;

END;
' LANGUAGE plpgsql;

CREATE TRIGGER insert_rental
AFTER INSERT ON game_rental
FOR EACH ROW EXECUTE PROCEDURE insert_rental();

-- Additionally, new procedures and triggers must be created

CREATE OR REPLACE FUNCTION delete_rental() 
RETURNS TRIGGER AS '
BEGIN
   UPDATE employees SET num_rent = num_rent-1 WHERE empl_code = OLD.empl_code;
RETURN NULL;
END;
' LANGUAGE plpgsql;


CREATE TRIGGER delete_rental
AFTER DELETE ON game_rental
FOR EACH ROW EXECUTE PROCEDURE delete_rental();

-- In this case, run 'after' to ensure the decrease is made
-- after the delete is executed correctly 

CREATE OR REPLACE FUNCTION modify_rental() 
RETURNS TRIGGER AS '
BEGIN
   UPDATE employees SET num_rent = num_rent-1 WHERE empl_code = OLD.empl_code;
   UPDATE employees SET num_rent = num_rent+1 WHERE empl_code = NEW.empl_code;
RETURN NEW;
END;
' LANGUAGE plpgsql;

CREATE TRIGGER modify_rental
AFTER UPDATE OF empl_code ON game_rental
FOR EACH ROW EXECUTE PROCEDURE modify_rental();

COMMIT WORK;

BEGIN WORK;

-- Insert video game rentals
-- Constraints imposed in DBVideoGamesI.sql are verified

SET DATESTYLE = DMY;
INSERT INTO game_rental VALUES(1, 1, '27-02-2006', NULL ,1);
INSERT INTO game_rental VALUES(2, 1, '20-02-2006', NULL, 1);
INSERT INTO game_rental VALUES(3, 2, CURRENT_DATE, NULL, 2);
INSERT INTO game_rental VALUES(4, 1, '28-02-2006', NULL, 2);
INSERT INTO game_rental VALUES(3, 5, '01-03-2006', NULL, 1);
INSERT INTO game_rental VALUES(4, 2, '01-03-2006', NULL, 2);
INSERT INTO game_rental VALUES(2, 2, '10-02-2006', NULL, 2);
INSERT INTO game_rental VALUES(5, 6, '10-02-2006', NULL, 2);
INSERT INTO game_rental VALUES(5, 7, '10-02-2006', NULL, 1);
INSERT INTO game_rental VALUES(5, 8, '10-02-2006', NULL, 3);
INSERT INTO game_rental VALUES(5, 6, '01-03-2006', NULL, 4);

-- Query the value of attribute num_rent of employees
-- to make sure it was correctly calculated

SELECT * FROM employees ORDER BY empl_code;

COMMIT WORK;

BEGIN WORK;

-- Delete video game rentals (for example, rentals made by employee with empl_code 2)

DELETE FROM game_rental WHERE empl_code = 2;

-- Query the value of attribute num_rent of employees to make sure it was correctly calculated for 
-- employee with empl_code 2

SELECT * FROM employees ORDER BY empl_code;

-- Restore situation prior to deletion 

INSERT INTO game_rental VALUES(3, 2, CURRENT_DATE, NULL, 2);
INSERT INTO game_rental VALUES(4, 1, '28-02-2006', NULL, 2);
INSERT INTO game_rental VALUES(4, 2, '01-03-2006', NULL, 2);
INSERT INTO game_rental VALUES(2, 2, '10-02-2006', NULL, 2);
INSERT INTO game_rental VALUES(5, 6, '10-02-2006', NULL, 2);

-- Query the value of the attribute num_rent of employees
-- to make sure it was correctly calculated 

SELECT * FROM employees ORDER BY empl_code;

COMMIT WORK;

BEGIN WORK;

-- Modify rentals arranged by an employee
-- All rentals by employee with empl_code 2 are transferred to employee 
-- with empl_code 5 (who has not arranged any rentals yet)

UPDATE game_rental SET empl_code = 5 WHERE empl_code = 2;

-- Verify that employee with empl_code 2 now has 0 rentals
-- and employee with empl_code 5 has arranged 5 rentals already


SELECT * FROM employees ORDER BY empl_code;

COMMIT WORK;

-- Incorrect transfer of video games rentals

BEGIN WORK;

UPDATE game_rental SET empl_code = 100 WHERE empl_code = 1;

ROLLBACK WORK;


